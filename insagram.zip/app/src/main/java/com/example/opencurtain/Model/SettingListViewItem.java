package com.example.opencurtain.Model;

public class SettingListViewItem {
    private String name;

    public String getName(){return  name;}

    public SettingListViewItem(String name){
        this.name = name;
    }
}