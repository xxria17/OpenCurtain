# OpenCurtain

### OpenCurtain Android version
- Django 서버를 이용한 대학교 커뮤니티 앱

### 
